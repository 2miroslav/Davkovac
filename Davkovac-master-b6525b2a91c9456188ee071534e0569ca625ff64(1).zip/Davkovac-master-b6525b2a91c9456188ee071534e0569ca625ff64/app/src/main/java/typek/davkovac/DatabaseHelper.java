package typek.davkovac;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Created by mrandlisek on 27. 11. 2017.
 */

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "Davkovac.db";
    private static final String TAG = "DatabaseHelper";
    private static final String TABLE_NAME = "userProfileDavkovac";
    private static final String COL1 = "ID";
    private static final String COL2 = "Name";
    private static final String COL3 = "Surname";
    private static final String COL4 = "Blood";
    private static final String COL5 = "ICE";

    public DatabaseHelper(Context context){
        super(context, DATABASE_NAME , null, 1);
        SQLiteDatabase db = this.getWritableDatabase();
    }
    @Override
    public void onCreate(SQLiteDatabase db){
        db.execSQL("create table " + TABLE_NAME +"( ID INTEGER PRIMARY KEY AUTOINCREMENT, Name TEXT, Surname TEXT, Blood TEXT, ICE INTEGER)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP IF TABLE EXISTS " +TABLE_NAME);
        onCreate(db);
    }
    public boolean addData(String Name, String Surname, String Blood, String ICE){
//
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues1 = new ContentValues();
        ContentValues contentValues2 = new ContentValues();
        ContentValues contentValues3 = new ContentValues();
        ContentValues contentValues4 = new ContentValues();
        contentValues1.put(COL2, Name);
        contentValues2.put(COL3, Surname);
        contentValues3.put(COL4, Blood);
        contentValues4.put(COL5, ICE);

        Log.d(TAG,"addData: Adding" + Name + "to" + TABLE_NAME);
        Log.d(TAG,"addData: Adding" + Surname + "to" + TABLE_NAME);
        Log.d(TAG,"addData: Adding" + Blood + "to" + TABLE_NAME);
        Log.d(TAG,"addData: Adding" + ICE + "to" + TABLE_NAME);

        long result = db.insert(TABLE_NAME,null, contentValues1);
        long result2 = db.insert(TABLE_NAME,null, contentValues2);
        long result3 = db.insert(TABLE_NAME,null, contentValues3);
        long result4 = db.insert(TABLE_NAME,null, contentValues4);

//        If data as inserted incorrectly it will return -1
        if (result == -1 || result2 == -1 || result3 == -1 || result4 == -1 ){
//
            return false;
        }else {
            return true;
        }
    }
}
