package typek.davkovac;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    private String selection;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void button_plus_klik(View view) {
        Intent myIntent = new Intent(MainActivity.this, PlusActivity.class);
        myIntent.putExtra("selection", this.selection);
        MainActivity.this.startActivity(myIntent);
    }

    public void button_prehliadka_klik(View view) {
        Intent myIntent = new Intent(MainActivity.this, PrehliadkaActivity.class);
        myIntent.putExtra("selection", this.selection);
        MainActivity.this.startActivity(myIntent);
    }

    public void button_kalendar_klik(View view) {
        Intent myIntent = new Intent(MainActivity.this, KalendarActivity.class);
        myIntent.putExtra("selection", this.selection);
        MainActivity.this.startActivity(myIntent);
    }

    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.toolbar, menu);
        return true;
    }
}
