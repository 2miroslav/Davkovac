package typek.davkovac;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class MainActivity_miro extends AppCompatActivity {

    private EditText Name;
    private EditText Surname;
    private EditText Blood;
    private EditText ICE;
    private Button Save;
    private Button Skip;

    DatabaseHelper mDatabaseHelpser;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_miro);





            Name = (EditText)findViewById(R.id.etName);
            Surname= (EditText)findViewById(R.id.etSurname);
            Blood = (EditText)findViewById(R.id.etBlood);
            ICE= (EditText)findViewById(R.id.etPhone);
            Save = (Button)findViewById(R.id.btnSave);
            Skip = (Button)findViewById(R.id.btnSkip);

            mDatabaseHelpser = new DatabaseHelper(this);

            Save.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String newName = Name.getText().toString();
                    String newSurname= Surname.getText().toString();
                    String newBlood= Blood.getText().toString();
                    String newICE= ICE.getText().toString();
                    if(Name.length() !=0 && Surname.length()!=0 && Blood.length() !=0 && ICE.length() != 0  ){
//
                        AddData(newName, newSurname,newBlood,newICE);
                        Intent intent = new Intent(MainActivity_miro.this, MainActivity.class);
                        startActivity(intent);
                    }else{
                        toastMessage("You must put something in the text fields!");
                    }
                }
            });

            Skip.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(MainActivity_miro.this, MainActivity.class);
                    startActivity(intent);
                }
            });


    }

    public void AddData(String newName, String newSurname, String newBlood, String newICE){
//
        boolean insertData = mDatabaseHelpser.addData(newName,newSurname,newBlood,newICE);

        if(insertData){
            toastMessage("Data Successfully Inserted");
        }else {
            toastMessage("Something went wrong");
        }
    }

    /*
     * customizable toast
     * @param message
     */
    private void toastMessage(String message){
        Toast.makeText(this,message, Toast.LENGTH_SHORT).show();
    }
}
