package typek.davkovac;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class PlusActivity extends AppCompatActivity {

    private EditText Name;
    private EditText ICE;
    private Button Save;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_plus);


        Name = (EditText)findViewById(R.id.etName);
        ICE= (EditText)findViewById(R.id.etPhone);
        Save = (Button)findViewById(R.id.btnSave);


        Save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String newName = Name.getText().toString();
                String newICE= ICE.getText().toString();
                if(Name.length() !=0 && ICE.length() != 0  ){
                    Intent intent = new Intent(PlusActivity.this, MainActivity.class);
                    startActivity(intent);
                }else{
                    toastMessage("You must put something in the text fields!");
                }
            }
        });
    }

    private void toastMessage(String message){
        Toast.makeText(this,message, Toast.LENGTH_SHORT).show();
    }

    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.toolbar, menu);
        return true;
    }
}
